import numpy as np

#задание матриц
c = np.array([[1, 0.9, 0.7], [0.9, 1, 0.4], [0.7, 0.4, 1]])
c1 = c.copy()
c1[2, 1] = 0.3; c1[1, 2] = 0.3
value, vector = np.linalg.eig(c1)
print(value)
c2 = np.zeros((3, 3))
#создание новой матрицы с заданными столбцами
for i in range(len(value)):
    if value[i] < 0:
        value[i] = 0
    c2[:, i] = vector[i] * value[i]
#нормализация строк
for i in range(c2.shape[0]):
    length = 0
    for j in range(len(c2[i])):
        length += c2[i, j] ** 2
    length = length ** 0.5
    for j in range(len(c2[i])):
        c2[i, j] = c2[i, j] / length
#проверка нормализованности строк
for i in range(c2.shape[0]):
    normalized = 0
    for j in range(len(c2[i])):
        normalized += c2[i, j] ** 2
    print(normalized)
new_matrix = c2 @ c2.T
print(c2, new_matrix, sep='\n')