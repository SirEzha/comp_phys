import numpy as np
import matplotlib.pyplot as plt

def plotting(x, x1 = -10, x2 = 30, y1 = 0, y2 = 1000000, bin_amount = 50):
    n, bins, patches = plt.hist(x, bin_amount, facecolor='g', alpha=0.75)
    plt.axis([x1, x2, y1, y2])
    plt.show()


a1 = np.random.randint(1, 6)
a2 = np.random.randint(1, 6)
a3 = np.random.randint(1, 6)
a4 = np.random.randint(1, 6)
a = np.array((a1, a2, a3, a4))
a = np.sort(a)
a_new = a[1:]
summ = np.sum(a_new)
number_list = np.zeros(int(1e6))
number_list[0] = summ
for i in range(1, int(1e6)):
    a1 = np.random.randint(1, 6)
    a2 = np.random.randint(1, 6)
    a3 = np.random.randint(1, 6)
    a4 = np.random.randint(1, 6)
    a = np.array((a1, a2, a3, a4))
    a = np.sort(a)
    a_new = a[1:]
    summ = np.sum(a_new)
    number_list[i] = summ
plotting(number_list)
