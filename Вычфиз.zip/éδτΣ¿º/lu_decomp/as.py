import numpy as np


def matrix_creation():
    a = np.arange(36)
    a = np.reshape(a, (6, 6))
    return a

def permutation_matrix(a):
    p = np.eye(a.shape[0])
    p1 = p.copy()
    for i in range(a.shape[0] - 1):
        p1[:,[i, i + 1]] = p1[:,[i + 1, i]]
    return a

a = matrix_creation()
u = a.copy()
print(a, u, sep='\n')
a = permutation_matrix(a)
