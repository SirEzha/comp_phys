import contextvars
import itertools
import numpy as np

def matrix_creation():
    a = np.arange(36)
    a = np.reshape(a, (6, 6))
    return a


a = matrix_creation()
u = a.copy()
i = 1
u[:,[i, i + 1]] = a[:,[i + 1, i]]
print(a, u, sep='\n')