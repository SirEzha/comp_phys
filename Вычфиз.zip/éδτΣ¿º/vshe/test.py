import numpy as np

a = np.array([[0, 0, 0, 1], [0, 0, 1, 0], [1, 0, 0, 0], [0, 1, 0 ,0]])
b = np.array([1, 2, 3, 4])
c = np.array([1043, 13, 4674, 283])
print(a @ a.T, np.dot(b, c), np.dot(a @ b, a @ c), sep='\n')