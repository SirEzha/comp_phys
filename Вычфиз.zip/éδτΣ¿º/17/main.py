import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as scipy


def task17(n=1000):
    a = np.random.normal(0, 1, (n, n))
    A = a + a.T
    evalues = np.linalg.eigvalsh(A)
    plt.hist(evalues, 10, density=True, facecolor='g', alpha=0.75)
    plt.show()

def task18(n=5, iterations=300):
    iterations_needed = iterations
    np.set_printoptions(precision=3)
    a = np.random.normal(0, 1, (n, n))
    A = a @ a.T
    H = scipy.hessenberg(A)
    for i in range(iterations):
        q, r = np.linalg.qr(H)
        H = r @ q
        minimum = H[0][0]
        for j in range(H.shape[0]):
            if H[j][j] < minimum: minimum = H[j][j]
        if (abs(minimum - np.linalg.eigvals(H)[-1]) /  np.linalg.eigvals(H)[-1]) <= 0.01:
            iterations_needed = i
            break
    print(H, np.linalg.eigvals(H), iterations_needed, sep='\n')


task17()
task18()
