import numpy as np

eye = np.eye(3)
print(np.linalg.inv(eye))