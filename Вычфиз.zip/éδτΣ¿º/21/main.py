import numpy as np
import scipy.linalg
import matplotlib.pyplot as plt

def kroneker(i, j):
    if i == j: return float(1)
    else: return float(0)

def matrix_creation(n=32):
    a = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            a[i][j] = -kroneker(i, j) + kroneker(i, j - 1) + kroneker(i, j - 2)
    return a

def exponent(a, points=100):
    t = np.linspace(0, 50, points)
    product = np.zeros(points)
    for i in range(points):
        product[i] = np.linalg.norm(scipy.linalg.expm(a * t[i]))
    plt.plot(t, product)
    plt.show()


a = matrix_creation()
exponent(a)